<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/annonce' => [[['_route' => 'annonce', '_controller' => 'App\\Controller\\AnnonceController::index'], null, null, null, false, false, null]],
        '/back' => [[['_route' => 'back', '_controller' => 'App\\Controller\\BackController::index'], null, null, null, false, false, null]],
        '/contact' => [[['_route' => 'contact', '_controller' => 'App\\Controller\\ContactController::index'], null, null, null, false, false, null]],
        '/Ajout/demande/emploi' => [[['_route' => 'Ajout_demande_emploi', '_controller' => 'App\\Controller\\DemandeEmploiController::Ajout'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/list/demande/emploi' => [[['_route' => 'list_demande_emploi', '_controller' => 'App\\Controller\\DemandeEmploiController::listeD'], null, ['GET' => 0], null, false, false, null]],
        '/list/demande/back' => [[['_route' => 'list_demande_back', '_controller' => 'App\\Controller\\DemandeEmploiController::listeDB'], null, ['GET' => 0], null, false, false, null]],
        '/espace/candidat' => [[['_route' => 'espace_candidat', '_controller' => 'App\\Controller\\EspaceCandidatController::index'], null, ['GET' => 0], null, false, false, null]],
        '/ajout/espace/candidat' => [[['_route' => 'ajout_espace_candidat', '_controller' => 'App\\Controller\\EspaceCandidatController::Add'], null, null, null, false, false, null]],
        '/aff/espace/candidat' => [[['_route' => 'aff_espace_candidat', '_controller' => 'App\\Controller\\EspaceCandidatController::listeD'], null, null, null, false, false, null]],
        '/Supp/espace/candidat' => [[['_route' => 'Supp_espace_candidat', '_controller' => 'App\\Controller\\EspaceCandidatController::listeSu'], null, null, null, false, false, null]],
        '/Modif/espace/candidat' => [[['_route' => 'Modif_espace_candidat', '_controller' => 'App\\Controller\\EspaceCandidatController::listeModif'], null, null, null, false, false, null]],
        '/affback/espace/candidat' => [[['_route' => 'affback_espace_candidat', '_controller' => 'App\\Controller\\EspaceCandidatController::listeAB'], null, null, null, false, false, null]],
        '/espace/employeur' => [[['_route' => 'espace_employeur', '_controller' => 'App\\Controller\\EspaceEmployeurController::index'], null, null, null, false, false, null]],
        '/ajout/espace/employeur' => [[['_route' => 'ajout_espace_employeur', '_controller' => 'App\\Controller\\EspaceEmployeurController::listA'], null, null, null, false, false, null]],
        '/aff/espace/employeur' => [[['_route' => 'aff_espace_employeur', '_controller' => 'App\\Controller\\EspaceEmployeurController::listeD'], null, null, null, false, false, null]],
        '/Supp/espace/employeur' => [[['_route' => 'Supp_espace_employeur', '_controller' => 'App\\Controller\\EspaceEmployeurController::listeSu'], null, null, null, false, false, null]],
        '/Modif/espace/employeur' => [[['_route' => 'Modif_espace_employeur', '_controller' => 'App\\Controller\\EspaceEmployeurController::listeModif'], null, null, null, false, false, null]],
        '/affback/espace/employeur' => [[['_route' => 'affback_espace_employeur', '_controller' => 'App\\Controller\\EspaceEmployeurController::listeAB'], null, null, null, false, false, null]],
        '/home' => [[['_route' => 'home', '_controller' => 'App\\Controller\\HomeController::index'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/Supp/demande/emploi/([^/]++)(*:198)'
                .'|/Modif/demande/emploi/([^/]++)(*:236)'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        198 => [[['_route' => 'Supp_demande_emploi', '_controller' => 'App\\Controller\\DemandeEmploiController::listeSu'], ['id'], ['DELETE' => 0], null, false, true, null]],
        236 => [
            [['_route' => 'Modif_demande_emploi', '_controller' => 'App\\Controller\\DemandeEmploiController::listeModif'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
