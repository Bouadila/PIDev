<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* baseCandidat.html.twig */
class __TwigTemplate_6813d623eed4c25ff53eeba478fc7f9f70f7be2b5ee3228d81a78ed2c52d0aa1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'css' => [$this, 'block_css'],
            'js' => [$this, 'block_js'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "baseCandidat.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "baseCandidat.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <title> ";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo " </title>

    ";
        // line 9
        $this->displayBlock('css', $context, $blocks);
        // line 20
        echo "
    ";
        // line 21
        $this->displayBlock('js', $context, $blocks);
        // line 25
        echo "


<section id=\"header\">
    <nav class=\"navbar navbar-default navbar-fixed-top\">
        <div class=\"container1\">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class=\"navbar-header col-sm-2\">
                <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar-collapse-2\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand\" href=\"";
        // line 39
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\">RECRUITINI</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class=\"col-sm-10\">
                <div class=\"collapse navbar-collapse\" id=\"navbar-collapse-2\">
                    <ul class=\"nav navbar-nav navbar col-sm-7\">
                        <li class=\"active\"><a href=\"";
        // line 45
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\">Acceuil</a></li>
                        <li><a href=\"";
        // line 46
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("Ajout_demande_emploi");
        echo "\">Demande Emploi</a></li>
                        <li><a href=\"offre.html\">Offre d'emploi</a></li>
                        <li><a href=\"annonce.html\">Annonce Presse</a></li>
                        <li><a href=\"";
        // line 49
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contact");
        echo "\">Contact</a></li>
                    </ul>
                    <ul class=\"nav navbar-nav navbar nav_1 col-sm-3\">
                        <li>
                            <div id=\"custom-search-input\">
                                <div class=\"input-group\">
                                    <input type=\"text\" class=\"  search-query form-control\" placeholder=\"Recherche\">
                                    <span class=\"input-group-btn\">
                                    <button class=\"btn btn-danger\" type=\"button\">
                                        <span class=\" glyphicon glyphicon-search\"></span>
                                    </button>
                                </span>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div>
        </div><!-- /.container -->
    </nav>

</section>
</head>

";
        // line 73
        $this->displayBlock('body', $context, $blocks);
        // line 77
        echo "

  <section id=\"footer\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-12\">
                <div class=\"col-sm-3\">
                    <div class=\"footer_1\">
                        <h2>Details</h2>
                        <p>Recruitini, le portail tunisien de l’emploi, accompagne les candidats comme les recruteurs pour un avenir meilleur !</p>
                    </div>
                </div>
                <div class=\"col-sm-3\">
                    <div class=\"footer_2\">
                        <h3>Pour nous contacter</h3>
                        <ul>
                            <li><a href=\"#\">Recuitini@gmail.com</a></li>
                            <li><a href=\"#\">123 4567 89 90</a></li>
                            <li>Lundi-Vendredi: 9h-17h </li>
                            <li>Samedi: 9h-13h </li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-sm-3\">
                    <div class=\"footer_2\">
                        <h3>Index</h3>
                        <ul>
                            <li><a href=\"";
        // line 104
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\">Acceuil</a></li>
                            <li><a href=\"#\">Offre d'emploi</a></li>
                            <li><a href=\"#\">Annonce presse</a></li>
                            <li><a href=\"";
        // line 107
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contact");
        echo "\">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </section>
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 7
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo " recruitini ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 9
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        // line 10
        echo "        <link href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/global.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/index.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/services.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/contact.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/ken-burns.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
        <link type=\"text/css\" rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/animate.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/font-awesome.min.css"), "html", null, true);
        echo "\" />
        <link href=\"https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap\" rel=\"stylesheet\">
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 21
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        // line 22
        echo "        <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/jquery-2.1.1.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 73
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 74
        echo "

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "baseCandidat.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  294 => 74,  284 => 73,  272 => 23,  267 => 22,  257 => 21,  244 => 17,  240 => 16,  236 => 15,  232 => 14,  228 => 13,  224 => 12,  220 => 11,  215 => 10,  205 => 9,  186 => 7,  166 => 107,  160 => 104,  131 => 77,  129 => 73,  102 => 49,  96 => 46,  92 => 45,  83 => 39,  67 => 25,  65 => 21,  62 => 20,  60 => 9,  55 => 7,  47 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <title> {% block title %} recruitini {% endblock %} </title>

    {% block css%}
        <link href=\"{{asset('css/bootstrap.min.css')}}\" rel=\"stylesheet\">
        <link href=\"{{asset('css/global.css')}}\" rel=\"stylesheet\">
        <link href=\"{{asset('css/index.css')}}\" rel=\"stylesheet\">
        <link href=\"{{asset('css/services.css')}}\" rel=\"stylesheet\">
        <link href=\"{{asset('css/contact.css')}}\" rel=\"stylesheet\">
        <link href=\"{{asset('css/ken-burns.css')}}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
        <link type=\"text/css\" rel=\"stylesheet\" href=\"{{asset('css/animate.css')}}\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"{{asset('css/font-awesome.min.css')}}\" />
        <link href=\"https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap\" rel=\"stylesheet\">
    {% endblock %}

    {% block js %}
        <script src=\"{{asset('js/jquery-2.1.1.min.js')}}\"></script>
        <script src=\"{{asset('js/bootstrap.min.js')}}\"></script>
    {% endblock %}



<section id=\"header\">
    <nav class=\"navbar navbar-default navbar-fixed-top\">
        <div class=\"container1\">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class=\"navbar-header col-sm-2\">
                <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar-collapse-2\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand\" href=\"{{ path('home') }}\">RECRUITINI</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class=\"col-sm-10\">
                <div class=\"collapse navbar-collapse\" id=\"navbar-collapse-2\">
                    <ul class=\"nav navbar-nav navbar col-sm-7\">
                        <li class=\"active\"><a href=\"{{ path('home') }}\">Acceuil</a></li>
                        <li><a href=\"{{ path('Ajout_demande_emploi') }}\">Demande Emploi</a></li>
                        <li><a href=\"offre.html\">Offre d'emploi</a></li>
                        <li><a href=\"annonce.html\">Annonce Presse</a></li>
                        <li><a href=\"{{ path('contact') }}\">Contact</a></li>
                    </ul>
                    <ul class=\"nav navbar-nav navbar nav_1 col-sm-3\">
                        <li>
                            <div id=\"custom-search-input\">
                                <div class=\"input-group\">
                                    <input type=\"text\" class=\"  search-query form-control\" placeholder=\"Recherche\">
                                    <span class=\"input-group-btn\">
                                    <button class=\"btn btn-danger\" type=\"button\">
                                        <span class=\" glyphicon glyphicon-search\"></span>
                                    </button>
                                </span>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div>
        </div><!-- /.container -->
    </nav>

</section>
</head>

{% block body %}


{% endblock %}


  <section id=\"footer\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-12\">
                <div class=\"col-sm-3\">
                    <div class=\"footer_1\">
                        <h2>Details</h2>
                        <p>Recruitini, le portail tunisien de l’emploi, accompagne les candidats comme les recruteurs pour un avenir meilleur !</p>
                    </div>
                </div>
                <div class=\"col-sm-3\">
                    <div class=\"footer_2\">
                        <h3>Pour nous contacter</h3>
                        <ul>
                            <li><a href=\"#\">Recuitini@gmail.com</a></li>
                            <li><a href=\"#\">123 4567 89 90</a></li>
                            <li>Lundi-Vendredi: 9h-17h </li>
                            <li>Samedi: 9h-13h </li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-sm-3\">
                    <div class=\"footer_2\">
                        <h3>Index</h3>
                        <ul>
                            <li><a href=\"{{ path('home') }}\">Acceuil</a></li>
                            <li><a href=\"#\">Offre d'emploi</a></li>
                            <li><a href=\"#\">Annonce presse</a></li>
                            <li><a href=\"{{ path('contact') }}\">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </section>
</html>
", "baseCandidat.html.twig", "C:\\Users\\User\\Documents\\pidev\\ProjPiDev\\templates\\baseCandidat.html.twig");
    }
}
