<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* demande_emploi/Modif_demande_emploi.html.twig */
class __TwigTemplate_71fc8fd478dd2c97cf8a5d6b145a155f1b0eeed55eb1dc804cceb52ac8483de7 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "baseCandidat.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "demande_emploi/Modif_demande_emploi.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "demande_emploi/Modif_demande_emploi.html.twig"));

        $this->parent = $this->loadTemplate("baseCandidat.html.twig", "demande_emploi/Modif_demande_emploi.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Modifier demande";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <!DOCTYPE html>
<html>
  <head>
    <title>Demande d'emploi</title>
    <link href=\"https://fonts.googleapis.com/css?family=Roboto:300,400,500,700\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.5.0/css/all.css\" integrity=\"sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU\" crossorigin=\"anonymous\">
    <style>
      html, body {
      min-height: 100%;
      }
      body, div, form, input, select, p {
      padding: 0;
      margin: 0;
      outline: none;
      font-family: Roboto, Arial, sans-serif;
      font-size: 14px;
      color: #666;
      line-height: 22px;
      }
      h1 {
      position: absolute;
      margin: 0;
      font-size: 38px;
      color: #fff;
      z-index: 2;
      }
      p.top-info {
      margin: 10px 0;
      }
      .testbox {
      display: flex;
      justify-content: center;
      align-items: center;
      height: inherit;
      padding: 20px;
      }
      textarea {
      width: calc(100% - 12px);
      padding: 5px;

      }
      form {
      width: 100%;
      padding: 20px;
      border-radius: 6px;
      background: #fff;
      box-shadow: 0 0 25px 0 #1c87c9;
      }
     .banner {
      position: relative;
      height: 210px;
      background-image: url(\"/uploads/media/default/0001/02/fb57ab781c34da322c884532bfec751e843e36fc.jpeg\");
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: center;
      }
      .banner::after {
      content: \"\";
      background-color: rgba(0, 0, 0, 0.6);
      position: absolute;
      width: 100%;
      height: 100%;
      }
      input, select, textarea {
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 3px;
      }
      input {
      width: calc(100% - 10px);
      padding: 5px;
      }
      input[type=\"date\"] {
      padding: 4px 5px;
      }
      select {
      width: 100%;
      padding: 7px 0;
      background: transparent;
      }
      .item:hover p, .item:hover i, .question:hover p, .question label:hover, input:hover::placeholder {
      color: #1c87c9;
      }
      .item input:hover, .item select:hover {
      border: 1px solid transparent;
      box-shadow: 0 0 6px 0 #1c87c9;
      color: #1c87c9;
      }
      .item {
      position: relative;
      margin: 10px 0;
      }
      input[type=\"date\"]::-webkit-inner-spin-button {
      display: none;
      }
      .item i, input[type=\"date\"]::-webkit-calendar-picker-indicator {
      position: absolute;
      font-size: 20px;
      color: #a9a9a9;
      }
      .item i {
      right: 2%;
      top: 30px;
      z-index: 1;
      }
      [type=\"date\"]::-webkit-calendar-picker-indicator {
      right: 1%;
      z-index: 2;
      opacity: 0;
      cursor: pointer;
      }
      input[type=radio]  {
      display: none;
      }
      label.radio {
      position: relative;
      display: inline-block;
      margin: 5px 20px 10px 0;
      cursor: pointer;
      }
      .question span {
      margin-left: 30px;
      }
      span.required {
      margin-left: 0;
      color: red;
      }
      label.radio:before {
      content: \"\";
      position: absolute;
      left: 0;
      width: 17px;
      height: 17px;
      border-radius: 50%;
      border: 2px solid #ccc;
      }
      input[type=radio]:checked + label:before, label.radio:hover:before {
      border: 2px solid #1c87c9;
      }
      label.radio:after {
      content: \"\";
      position: absolute;
      top: 6px;
      left: 5px;
      width: 8px;
      height: 4px;
      border: 3px solid #1c87c9;
      border-top: none;
      border-right: none;
      transform: rotate(-45deg);
      opacity: 0;
      }
      input[type=radio]:checked + label:after {
      opacity: 1;
      }
      .btn-block {
      margin-top: 10px;
      text-align: center;
      }
      button {
      width: auto;
      padding: 10px;
      border: none;
      border-radius: 5px;
      background: #1c87c9;
      font-size: 16px;
      font-weight: 700;
      color: #fff;
      cursor: pointer;
      }
      button:hover {
      background: #1e6fa0;
      }
      @media (min-width: 568px) {
      .name-item, .contact-item, .position-item {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      }
      .name-item input {
      width: calc(50% - 20px);
      }
      .contact-item .item, .position-item .item {
      width: calc(50% - 8px);
      }
      .contact-item input, .position-item input {
      width: calc(100% - 12px);
      }
      .position-item select {
      width: 100%;
      }
      }
      </style>
  </head>
  <body>
    <div class=\"testbox\">
      <form ";
        // line 204
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["formdemande"]) || array_key_exists("formdemande", $context) ? $context["formdemande"] : (function () { throw new RuntimeError('Variable "formdemande" does not exist.', 204, $this->source); })()), 'form_start');
        echo " >
        <div class=\"banner\">
          <h1>Créer votre demande de recherche</h1>
        </div>
        <p class=\"top-info\">Veuillez remplir le formulaire </p>
        <div class=\"item\">
        <p>Titre de votre demande<span >*</span></p>
          <div class=\"name-item\">
                ";
        // line 212
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formdemande"]) || array_key_exists("formdemande", $context) ? $context["formdemande"] : (function () { throw new RuntimeError('Variable "formdemande" does not exist.', 212, $this->source); })()), "TitreDemande", [], "any", false, false, false, 212), 'widget');
        echo "
          </div>
           <p>Nom<span >*</span></p>
          <div class=\"name-item\">
                ";
        // line 216
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formdemande"]) || array_key_exists("formdemande", $context) ? $context["formdemande"] : (function () { throw new RuntimeError('Variable "formdemande" does not exist.', 216, $this->source); })()), "nomCand", [], "any", false, false, false, 216), 'widget');
        echo "
          </div>
          <p>Prenom<span >*</span></p>
          <div class=\"name-item\">
                ";
        // line 220
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formdemande"]) || array_key_exists("formdemande", $context) ? $context["formdemande"] : (function () { throw new RuntimeError('Variable "formdemande" does not exist.', 220, $this->source); })()), "prenomCand", [], "any", false, false, false, 220), 'widget');
        echo "
          </div>
          <p>Email<span >*</span></p>
          <div class=\"name-item\">
                ";
        // line 224
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formdemande"]) || array_key_exists("formdemande", $context) ? $context["formdemande"] : (function () { throw new RuntimeError('Variable "formdemande" does not exist.', 224, $this->source); })()), "emailCand", [], "any", false, false, false, 224), 'widget');
        echo "
          </div>
          <p>Numéro<span >*</span></p>
           <div class=\"name-item\">
                          ";
        // line 228
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formdemande"]) || array_key_exists("formdemande", $context) ? $context["formdemande"] : (function () { throw new RuntimeError('Variable "formdemande" does not exist.', 228, $this->source); })()), "numCand", [], "any", false, false, false, 228), 'widget');
        echo "
          </div>
          <p>Adresse<span >*</span></p>
           <div class=\"name-item\">
                          ";
        // line 232
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formdemande"]) || array_key_exists("formdemande", $context) ? $context["formdemande"] : (function () { throw new RuntimeError('Variable "formdemande" does not exist.', 232, $this->source); })()), "adresseCand", [], "any", false, false, false, 232), 'widget');
        echo "
          </div>
          <p>Votre Domaine<span >*</span></p>
           <div class=\"name-item\">
                          ";
        // line 236
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formdemande"]) || array_key_exists("formdemande", $context) ? $context["formdemande"] : (function () { throw new RuntimeError('Variable "formdemande" does not exist.', 236, $this->source); })()), "domaineTravail", [], "any", false, false, false, 236), 'widget');
        echo "
          </div>
          <p>Statut<span >*</span></p>
           <div class=\"name-item\">
                          ";
        // line 240
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formdemande"]) || array_key_exists("formdemande", $context) ? $context["formdemande"] : (function () { throw new RuntimeError('Variable "formdemande" does not exist.', 240, $this->source); })()), "statutCand", [], "any", false, false, false, 240), 'widget');
        echo "
          </div>
          <p>Description<span >*</span></p>
           <div class=\"name-item\">
                          ";
        // line 244
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formdemande"]) || array_key_exists("formdemande", $context) ? $context["formdemande"] : (function () { throw new RuntimeError('Variable "formdemande" does not exist.', 244, $this->source); })()), "description", [], "any", false, false, false, 244), 'widget');
        echo "
          </div>
           <p>Votre CV<span >*</span></p>
           <div class=\"name-item\">
                          ";
        // line 248
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formdemande"]) || array_key_exists("formdemande", $context) ? $context["formdemande"] : (function () { throw new RuntimeError('Variable "formdemande" does not exist.', 248, $this->source); })()), "cvCand", [], "any", false, false, false, 248), 'widget');
        echo "
          </div>
                </form ";
        // line 250
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["formdemande"]) || array_key_exists("formdemande", $context) ? $context["formdemande"] : (function () { throw new RuntimeError('Variable "formdemande" does not exist.', 250, $this->source); })()), 'form_end');
        echo " >
         </div>
    </div>
  </body>
</html>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "demande_emploi/Modif_demande_emploi.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  367 => 250,  362 => 248,  355 => 244,  348 => 240,  341 => 236,  334 => 232,  327 => 228,  320 => 224,  313 => 220,  306 => 216,  299 => 212,  288 => 204,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'baseCandidat.html.twig' %}

{% block title %}Modifier demande{% endblock %}

{% block body %}
    <!DOCTYPE html>
<html>
  <head>
    <title>Demande d'emploi</title>
    <link href=\"https://fonts.googleapis.com/css?family=Roboto:300,400,500,700\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.5.0/css/all.css\" integrity=\"sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU\" crossorigin=\"anonymous\">
    <style>
      html, body {
      min-height: 100%;
      }
      body, div, form, input, select, p {
      padding: 0;
      margin: 0;
      outline: none;
      font-family: Roboto, Arial, sans-serif;
      font-size: 14px;
      color: #666;
      line-height: 22px;
      }
      h1 {
      position: absolute;
      margin: 0;
      font-size: 38px;
      color: #fff;
      z-index: 2;
      }
      p.top-info {
      margin: 10px 0;
      }
      .testbox {
      display: flex;
      justify-content: center;
      align-items: center;
      height: inherit;
      padding: 20px;
      }
      textarea {
      width: calc(100% - 12px);
      padding: 5px;

      }
      form {
      width: 100%;
      padding: 20px;
      border-radius: 6px;
      background: #fff;
      box-shadow: 0 0 25px 0 #1c87c9;
      }
     .banner {
      position: relative;
      height: 210px;
      background-image: url(\"/uploads/media/default/0001/02/fb57ab781c34da322c884532bfec751e843e36fc.jpeg\");
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: center;
      }
      .banner::after {
      content: \"\";
      background-color: rgba(0, 0, 0, 0.6);
      position: absolute;
      width: 100%;
      height: 100%;
      }
      input, select, textarea {
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 3px;
      }
      input {
      width: calc(100% - 10px);
      padding: 5px;
      }
      input[type=\"date\"] {
      padding: 4px 5px;
      }
      select {
      width: 100%;
      padding: 7px 0;
      background: transparent;
      }
      .item:hover p, .item:hover i, .question:hover p, .question label:hover, input:hover::placeholder {
      color: #1c87c9;
      }
      .item input:hover, .item select:hover {
      border: 1px solid transparent;
      box-shadow: 0 0 6px 0 #1c87c9;
      color: #1c87c9;
      }
      .item {
      position: relative;
      margin: 10px 0;
      }
      input[type=\"date\"]::-webkit-inner-spin-button {
      display: none;
      }
      .item i, input[type=\"date\"]::-webkit-calendar-picker-indicator {
      position: absolute;
      font-size: 20px;
      color: #a9a9a9;
      }
      .item i {
      right: 2%;
      top: 30px;
      z-index: 1;
      }
      [type=\"date\"]::-webkit-calendar-picker-indicator {
      right: 1%;
      z-index: 2;
      opacity: 0;
      cursor: pointer;
      }
      input[type=radio]  {
      display: none;
      }
      label.radio {
      position: relative;
      display: inline-block;
      margin: 5px 20px 10px 0;
      cursor: pointer;
      }
      .question span {
      margin-left: 30px;
      }
      span.required {
      margin-left: 0;
      color: red;
      }
      label.radio:before {
      content: \"\";
      position: absolute;
      left: 0;
      width: 17px;
      height: 17px;
      border-radius: 50%;
      border: 2px solid #ccc;
      }
      input[type=radio]:checked + label:before, label.radio:hover:before {
      border: 2px solid #1c87c9;
      }
      label.radio:after {
      content: \"\";
      position: absolute;
      top: 6px;
      left: 5px;
      width: 8px;
      height: 4px;
      border: 3px solid #1c87c9;
      border-top: none;
      border-right: none;
      transform: rotate(-45deg);
      opacity: 0;
      }
      input[type=radio]:checked + label:after {
      opacity: 1;
      }
      .btn-block {
      margin-top: 10px;
      text-align: center;
      }
      button {
      width: auto;
      padding: 10px;
      border: none;
      border-radius: 5px;
      background: #1c87c9;
      font-size: 16px;
      font-weight: 700;
      color: #fff;
      cursor: pointer;
      }
      button:hover {
      background: #1e6fa0;
      }
      @media (min-width: 568px) {
      .name-item, .contact-item, .position-item {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      }
      .name-item input {
      width: calc(50% - 20px);
      }
      .contact-item .item, .position-item .item {
      width: calc(50% - 8px);
      }
      .contact-item input, .position-item input {
      width: calc(100% - 12px);
      }
      .position-item select {
      width: 100%;
      }
      }
      </style>
  </head>
  <body>
    <div class=\"testbox\">
      <form {{ form_start(formdemande) }} >
        <div class=\"banner\">
          <h1>Créer votre demande de recherche</h1>
        </div>
        <p class=\"top-info\">Veuillez remplir le formulaire </p>
        <div class=\"item\">
        <p>Titre de votre demande<span >*</span></p>
          <div class=\"name-item\">
                {{ form_widget(formdemande.TitreDemande) }}
          </div>
           <p>Nom<span >*</span></p>
          <div class=\"name-item\">
                {{ form_widget(formdemande.nomCand) }}
          </div>
          <p>Prenom<span >*</span></p>
          <div class=\"name-item\">
                {{ form_widget(formdemande.prenomCand) }}
          </div>
          <p>Email<span >*</span></p>
          <div class=\"name-item\">
                {{ form_widget(formdemande.emailCand) }}
          </div>
          <p>Numéro<span >*</span></p>
           <div class=\"name-item\">
                          {{ form_widget(formdemande.numCand) }}
          </div>
          <p>Adresse<span >*</span></p>
           <div class=\"name-item\">
                          {{ form_widget(formdemande.adresseCand) }}
          </div>
          <p>Votre Domaine<span >*</span></p>
           <div class=\"name-item\">
                          {{ form_widget(formdemande.domaineTravail) }}
          </div>
          <p>Statut<span >*</span></p>
           <div class=\"name-item\">
                          {{ form_widget(formdemande.statutCand) }}
          </div>
          <p>Description<span >*</span></p>
           <div class=\"name-item\">
                          {{ form_widget(formdemande.description) }}
          </div>
           <p>Votre CV<span >*</span></p>
           <div class=\"name-item\">
                          {{ form_widget(formdemande.cvCand) }}
          </div>
                </form {{ form_end(formdemande) }} >
         </div>
    </div>
  </body>
</html>
{% endblock %}
", "demande_emploi/Modif_demande_emploi.html.twig", "C:\\Users\\User\\Documents\\pidev\\ProjPiDev\\templates\\demande_emploi\\Modif_demande_emploi.html.twig");
    }
}
