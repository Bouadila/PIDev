<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* baseBack.html.twig */
class __TwigTemplate_a23d3a062fc87b8d3ffd6a026492bf114318af7786e9c3c1cd9a4ac7db4d632f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'css' => [$this, 'block_css'],
            'js' => [$this, 'block_js'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "baseBack.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "baseBack.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <title> ";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo " </title>

    ";
        // line 9
        $this->displayBlock('css', $context, $blocks);
        // line 38
        echo "
    ";
        // line 39
        $this->displayBlock('js', $context, $blocks);
        // line 56
        echo "
</head>


<div class=\"container-scroller\">
    <!-- partial:partials/_navbar.html -->
    <nav class=\"navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row\">
        <div class=\"text-center navbar-brand-wrapper d-flex align-items-top justify-content-center\">
            <a class=\"navbar-brand brand-logo\" href=\"";
        // line 64
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("back");
        echo "\">
                <img src=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/logo.svg"), "html", null, true);
        echo "\" alt=\"logo\" /> </a>
            <a class=\"navbar-brand brand-logo-mini\" href=\"";
        // line 66
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("back");
        echo "\">
                <img src=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/logo-mini.svg"), "html", null, true);
        echo "\" alt=\"logo\" /> </a>
        </div>
        <div class=\"navbar-menu-wrapper d-flex align-items-center\">
            <ul class=\"navbar-nav\">
                <li class=\"nav-item font-weight-semibold d-none d-lg-block\">Numéro : +050 2992 709</li>
            </ul>
            <form class=\"ml-auto search-form d-none d-md-block\" action=\"#\">
                <div class=\"form-group\">
                    <input type=\"search\" class=\"form-control\" placeholder=\"Recherche\">
                </div>
            </form>
            <ul class=\"navbar-nav ml-auto\">
                <li class=\"nav-item dropdown\">
                    <a class=\"nav-link count-indicator\" id=\"messageDropdown\" href=\"#\" data-toggle=\"dropdown\" aria-expanded=\"false\">
                        <i class=\"mdi mdi-bell-outline\"></i>
                        <span class=\"count\">100</span>
                    </a>
                    <div class=\"dropdown-menu dropdown-menu-right navbar-dropdown preview-list pb-0\" aria-labelledby=\"messageDropdown\">
                        <a class=\"dropdown-item py-3\">
                            <p class=\"mb-0 font-weight-medium float-left\">You have 7 unread mails </p>
                            <span class=\"badge badge-pill badge-primary float-right\">View all</span>
                        </a>
                        <div class=\"dropdown-divider\"></div>
                        <a class=\"dropdown-item preview-item\">
                            <div class=\"preview-thumbnail\">
                                <img src=\"";
        // line 92
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/faces/face10.jpg"), "html", null, true);
        echo "\" alt=\"image\" class=\"img-sm profile-pic\">
                            </div>
                            <div class=\"preview-item-content flex-grow py-2\">
                                <p class=\"preview-subject ellipsis font-weight-medium text-dark\">Marian Garner </p>
                                <p class=\"font-weight-light small-text\"> The meeting is cancelled </p>
                            </div>
                        </a>
                        <a class=\"dropdown-item preview-item\">
                            <div class=\"preview-thumbnail\">
                                <img src=\"";
        // line 101
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/faces/face12.jpg"), "html", null, true);
        echo "\" alt=\"image\" class=\"img-sm profile-pic\">
                            </div>
                            <div class=\"preview-item-content flex-grow py-2\">
                                <p class=\"preview-subject ellipsis font-weight-medium text-dark\">David Grey </p>
                                <p class=\"font-weight-light small-text\"> The meeting is cancelled </p>
                            </div>
                        </a>
                        <a class=\"dropdown-item preview-item\">
                            <div class=\"preview-thumbnail\">
                                <img src=\"";
        // line 110
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/faces/face1.jpg"), "html", null, true);
        echo "\" alt=\"image\" class=\"img-sm profile-pic\">
                            </div>
                            <div class=\"preview-item-content flex-grow py-2\">
                                <p class=\"preview-subject ellipsis font-weight-medium text-dark\">Travis Jenkins </p>
                                <p class=\"font-weight-light small-text\"> The meeting is cancelled </p>
                            </div>
                        </a>
                    </div>
                </li>
                <li class=\"nav-item dropdown\">
                    <a class=\"nav-link count-indicator\" id=\"notificationDropdown\" href=\"#\" data-toggle=\"dropdown\">
                        <i class=\"mdi mdi-email-outline\"></i>
                        <span class=\"count bg-success\">3</span>
                    </a>
                    <div class=\"dropdown-menu dropdown-menu-right navbar-dropdown preview-list pb-0\" aria-labelledby=\"notificationDropdown\">
                        <a class=\"dropdown-item py-3 border-bottom\">
                            <p class=\"mb-0 font-weight-medium float-left\">You have 4 new notifications </p>
                            <span class=\"badge badge-pill badge-primary float-right\">View all</span>
                        </a>
                        <a class=\"dropdown-item preview-item py-3\">
                            <div class=\"preview-thumbnail\">
                                <i class=\"mdi mdi-alert m-auto text-primary\"></i>
                            </div>
                            <div class=\"preview-item-content\">
                                <h6 class=\"preview-subject font-weight-normal text-dark mb-1\">Application Error</h6>
                                <p class=\"font-weight-light small-text mb-0\"> Just now </p>
                            </div>
                        </a>
                        <a class=\"dropdown-item preview-item py-3\">
                            <div class=\"preview-thumbnail\">
                                <i class=\"mdi mdi-settings m-auto text-primary\"></i>
                            </div>
                            <div class=\"preview-item-content\">
                                <h6 class=\"preview-subject font-weight-normal text-dark mb-1\">Settings</h6>
                                <p class=\"font-weight-light small-text mb-0\"> Private message </p>
                            </div>
                        </a>
                        <a class=\"dropdown-item preview-item py-3\">
                            <div class=\"preview-thumbnail\">
                                <i class=\"mdi mdi-airballoon m-auto text-primary\"></i>
                            </div>
                            <div class=\"preview-item-content\">
                                <h6 class=\"preview-subject font-weight-normal text-dark mb-1\">New user registration</h6>
                                <p class=\"font-weight-light small-text mb-0\"> 2 days ago </p>
                            </div>
                        </a>
                    </div>
                </li>
                <li class=\"nav-item dropdown d-none d-xl-inline-block user-dropdown\">
                    <a class=\"nav-link dropdown-toggle\" id=\"UserDropdown\" href=\"#\" data-toggle=\"dropdown\" aria-expanded=\"false\">
                        <img class=\"img-xs rounded-circle\" src=\"";
        // line 160
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/faces/face8.jpg"), "html", null, true);
        echo "\" alt=\"Profile image\"> </a>
                    <div class=\"dropdown-menu dropdown-menu-right navbar-dropdown\" aria-labelledby=\"UserDropdown\">
                        <div class=\"dropdown-header text-center\">
                            <img class=\"img-md rounded-circle\" src=\"";
        // line 163
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/faces/face8.jpg"), "html", null, true);
        echo "\" alt=\"Profile image\">
                            <p class=\"mb-1 mt-3 font-weight-semibold\">Allen Moreno</p>
                            <p class=\"font-weight-light text-muted mb-0\">allenmoreno@gmail.com</p>
                        </div>
                        <a class=\"dropdown-item\">Mon Profile <span class=\"badge badge-pill badge-danger\">1</span><i class=\"dropdown-item-icon ti-dashboard\"></i></a>
                        <a class=\"dropdown-item\">Messages<i class=\"dropdown-item-icon ti-comment-alt\"></i></a>
                        <a class=\"dropdown-item\">Sign Out<i class=\"dropdown-item-icon ti-power-off\"></i></a>
                    </div>
                </li>
            </ul>
            <button class=\"navbar-toggler navbar-toggler-right d-lg-none align-self-center\" type=\"button\" data-toggle=\"offcanvas\">
                <span class=\"mdi mdi-menu\"></span>
            </button>
        </div>
    </nav>
    <!-- partial -->
    <div class=\"container-fluid page-body-wrapper\">
        <!-- partial:partials/_sidebar.html -->
        <nav class=\"sidebar sidebar-offcanvas\" id=\"sidebar\">
            <ul class=\"nav\">
                <li class=\"nav-item nav-profile\">
                    <a href=\"#\" class=\"nav-link\">
                        <div class=\"profile-image\">
                            <img class=\"img-xs rounded-circle\" src=\"";
        // line 186
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/faces/face8.jpg"), "html", null, true);
        echo "\" alt=\"profile image\">
                            <div class=\"dot-indicator bg-success\"></div>
                        </div>
                    </a>
                </li>
                <li class=\"nav-item nav-category\">Acceuil</li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" href=\"";
        // line 193
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("back");
        echo "\">
                        <i class=\"menu-icon typcn typcn-document-text\"></i>
                        <span class=\"menu-title\">Acceuil</span>
                    </a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" data-toggle=\"collapse\" href=\"#ui-basic\" aria-expanded=\"false\" aria-controls=\"ui-basic\">
                        <i class=\"menu-icon typcn typcn-coffee\"></i>
                        <span class=\"menu-title\">Espace Entreprise</span>
                        <i class=\"menu-arrow\"></i>
                    </a>
                    <div class=\"collapse\" id=\"ui-basic\">
                        <ul class=\"nav flex-column sub-menu\">
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"pages/ui-features/buttons.html\">Comptes</a>
                            </li>
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"pages/ui-features/dropdowns.html\">Offres</a>
                            </li>
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"pages/ui-features/typography.html\">Réclamations</a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" data-toggle=\"collapse\" href=\"#auth\" aria-expanded=\"false\" aria-controls=\"auth\">
                        <i class=\"menu-icon typcn typcn-document-add\"></i>
                        <span class=\"menu-title\">Espace Candidat</span>
                        <i class=\"menu-arrow\"></i>
                    </a>
                    <div class=\"collapse\" id=\"auth\">
                        <ul class=\"nav flex-column sub-menu\">
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"pages/samples/blank-page.html\"> Comptes </a>
                            </li>
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"";
        // line 230
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("list_demande_back");
        echo "\"> Demandes </a>
                            </li>
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"pages/samples/register.html\"> Candidatures </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" href=\"pages/charts/chartjs.html\">
                        <i class=\"menu-icon typcn typcn-th-large-outline\"></i>
                        <span class=\"menu-title\">Charts</span>
                    </a>
                </li>
            </ul>
        </nav>

";
        // line 247
        $this->displayBlock('body', $context, $blocks);
        // line 250
        echo "



</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 7
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo " recruitini ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 9
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        // line 10
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendors/mdi/css/materialdesignicons.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendors/base/vendor.bundle.base.css"), "html", null, true);
        echo "\">
        <!-- endinject -->
        <!-- plugin css for this page -->
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendors/datatables.net-bs4/dataTables.bootstrap4.css"), "html", null, true);
        echo "\">
        <!-- End plugin css for this page -->
        <!-- inject:css -->
        <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <!-- endinject -->
        <link rel=\"shortcut icon\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/favicon.png"), "html", null, true);
        echo "\" />

        <!-- plugins:css -->
        <link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendors/iconfonts/mdi/css/materialdesignicons.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendors/iconfonts/ionicons/dist/css/ionicons.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendors/iconfonts/flag-icon-css/css/flag-icon.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendors/css/vendor.bundle.base.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendors/css/vendor.bundle.addons.css"), "html", null, true);
        echo "\">
        <!-- endinject -->
        <!-- plugin css for this page -->
        <!-- End plugin css for this page -->
        <!-- inject:css -->
        <link rel=\"stylesheet\" href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/shared/style.css"), "html", null, true);
        echo "\">
        <!-- endinject -->
        <!-- Layout styles -->
        <link rel=\"stylesheet\" href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/demo_1/style.css"), "html", null, true);
        echo "\">
        <!-- End Layout styles -->
        <link rel=\"shortcut icon\" href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("images/favicon.ico"), "html", null, true);
        echo "\" />
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 39
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        // line 40
        echo "        <!-- container-scroller -->
        <!-- plugins:js -->
        <script src=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendors/js/vendor.bundle.base.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("vendors/js/vendor.bundle.addons.js"), "html", null, true);
        echo "\"></script>
        <!-- endinject -->
        <!-- Plugin js for this page-->
        <!-- End plugin js for this page-->
        <!-- inject:js -->
        <script src=\"";
        // line 48
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/shared/off-canvas.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/shared/misc.js"), "html", null, true);
        echo "\"></script>
        <!-- endinject -->
        <!-- Custom js for this page-->
        <script src=\"";
        // line 52
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/demo_1/dashboard.js"), "html", null, true);
        echo "\"></script>
        <!-- End custom js for this page-->
        <script src=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/shared/jquery.cookie.js"), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 247
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 248
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "baseBack.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  480 => 248,  470 => 247,  458 => 54,  453 => 52,  447 => 49,  443 => 48,  435 => 43,  431 => 42,  427 => 40,  417 => 39,  405 => 36,  400 => 34,  394 => 31,  386 => 26,  382 => 25,  378 => 24,  374 => 23,  370 => 22,  364 => 19,  359 => 17,  353 => 14,  347 => 11,  342 => 10,  332 => 9,  313 => 7,  298 => 250,  296 => 247,  276 => 230,  236 => 193,  226 => 186,  200 => 163,  194 => 160,  141 => 110,  129 => 101,  117 => 92,  89 => 67,  85 => 66,  81 => 65,  77 => 64,  67 => 56,  65 => 39,  62 => 38,  60 => 9,  55 => 7,  47 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <title> {% block title %} recruitini {% endblock %} </title>

    {% block css%}
        <link rel=\"stylesheet\" href=\"{{asset('vendors/mdi/css/materialdesignicons.min.css')}}\">
        <link rel=\"stylesheet\" href=\"{{asset('vendors/base/vendor.bundle.base.css')}}\">
        <!-- endinject -->
        <!-- plugin css for this page -->
        <link rel=\"stylesheet\" href=\"{{asset('vendors/datatables.net-bs4/dataTables.bootstrap4.css')}}\">
        <!-- End plugin css for this page -->
        <!-- inject:css -->
        <link rel=\"stylesheet\" href=\"{{asset('css/style.css')}}\">
        <!-- endinject -->
        <link rel=\"shortcut icon\" href=\"{{ asset('images/favicon.png') }}\" />

        <!-- plugins:css -->
        <link rel=\"stylesheet\" href=\"{{ asset('vendors/iconfonts/mdi/css/materialdesignicons.min.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('vendors/iconfonts/ionicons/dist/css/ionicons.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('vendors/iconfonts/flag-icon-css/css/flag-icon.min.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('vendors/css/vendor.bundle.base.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('vendors/css/vendor.bundle.addons.css') }}\">
        <!-- endinject -->
        <!-- plugin css for this page -->
        <!-- End plugin css for this page -->
        <!-- inject:css -->
        <link rel=\"stylesheet\" href=\"{{ asset('css/shared/style.css') }}\">
        <!-- endinject -->
        <!-- Layout styles -->
        <link rel=\"stylesheet\" href=\"{{ asset('css/demo_1/style.css') }}\">
        <!-- End Layout styles -->
        <link rel=\"shortcut icon\" href=\"{{ asset('images/favicon.ico') }}\" />
    {% endblock %}

    {% block js %}
        <!-- container-scroller -->
        <!-- plugins:js -->
        <script src=\"{{ asset('vendors/js/vendor.bundle.base.js') }}\"></script>
        <script src=\"{{ asset('vendors/js/vendor.bundle.addons.js') }}\"></script>
        <!-- endinject -->
        <!-- Plugin js for this page-->
        <!-- End plugin js for this page-->
        <!-- inject:js -->
        <script src=\"{{ asset('js/shared/off-canvas.js') }}\"></script>
        <script src=\"{{ asset('js/shared/misc.js') }}\"></script>
        <!-- endinject -->
        <!-- Custom js for this page-->
        <script src=\"{{ asset('js/demo_1/dashboard.js') }}\"></script>
        <!-- End custom js for this page-->
        <script src=\"{{ asset('js/shared/jquery.cookie.js') }}\" type=\"text/javascript\"></script>
    {% endblock %}

</head>


<div class=\"container-scroller\">
    <!-- partial:partials/_navbar.html -->
    <nav class=\"navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row\">
        <div class=\"text-center navbar-brand-wrapper d-flex align-items-top justify-content-center\">
            <a class=\"navbar-brand brand-logo\" href=\"{{ path('back') }}\">
                <img src=\"{{ asset('images/logo.svg') }}\" alt=\"logo\" /> </a>
            <a class=\"navbar-brand brand-logo-mini\" href=\"{{ path('back') }}\">
                <img src=\"{{ asset('images/logo-mini.svg') }}\" alt=\"logo\" /> </a>
        </div>
        <div class=\"navbar-menu-wrapper d-flex align-items-center\">
            <ul class=\"navbar-nav\">
                <li class=\"nav-item font-weight-semibold d-none d-lg-block\">Numéro : +050 2992 709</li>
            </ul>
            <form class=\"ml-auto search-form d-none d-md-block\" action=\"#\">
                <div class=\"form-group\">
                    <input type=\"search\" class=\"form-control\" placeholder=\"Recherche\">
                </div>
            </form>
            <ul class=\"navbar-nav ml-auto\">
                <li class=\"nav-item dropdown\">
                    <a class=\"nav-link count-indicator\" id=\"messageDropdown\" href=\"#\" data-toggle=\"dropdown\" aria-expanded=\"false\">
                        <i class=\"mdi mdi-bell-outline\"></i>
                        <span class=\"count\">100</span>
                    </a>
                    <div class=\"dropdown-menu dropdown-menu-right navbar-dropdown preview-list pb-0\" aria-labelledby=\"messageDropdown\">
                        <a class=\"dropdown-item py-3\">
                            <p class=\"mb-0 font-weight-medium float-left\">You have 7 unread mails </p>
                            <span class=\"badge badge-pill badge-primary float-right\">View all</span>
                        </a>
                        <div class=\"dropdown-divider\"></div>
                        <a class=\"dropdown-item preview-item\">
                            <div class=\"preview-thumbnail\">
                                <img src=\"{{ asset('images/faces/face10.jpg') }}\" alt=\"image\" class=\"img-sm profile-pic\">
                            </div>
                            <div class=\"preview-item-content flex-grow py-2\">
                                <p class=\"preview-subject ellipsis font-weight-medium text-dark\">Marian Garner </p>
                                <p class=\"font-weight-light small-text\"> The meeting is cancelled </p>
                            </div>
                        </a>
                        <a class=\"dropdown-item preview-item\">
                            <div class=\"preview-thumbnail\">
                                <img src=\"{{ asset('images/faces/face12.jpg') }}\" alt=\"image\" class=\"img-sm profile-pic\">
                            </div>
                            <div class=\"preview-item-content flex-grow py-2\">
                                <p class=\"preview-subject ellipsis font-weight-medium text-dark\">David Grey </p>
                                <p class=\"font-weight-light small-text\"> The meeting is cancelled </p>
                            </div>
                        </a>
                        <a class=\"dropdown-item preview-item\">
                            <div class=\"preview-thumbnail\">
                                <img src=\"{{ asset('images/faces/face1.jpg') }}\" alt=\"image\" class=\"img-sm profile-pic\">
                            </div>
                            <div class=\"preview-item-content flex-grow py-2\">
                                <p class=\"preview-subject ellipsis font-weight-medium text-dark\">Travis Jenkins </p>
                                <p class=\"font-weight-light small-text\"> The meeting is cancelled </p>
                            </div>
                        </a>
                    </div>
                </li>
                <li class=\"nav-item dropdown\">
                    <a class=\"nav-link count-indicator\" id=\"notificationDropdown\" href=\"#\" data-toggle=\"dropdown\">
                        <i class=\"mdi mdi-email-outline\"></i>
                        <span class=\"count bg-success\">3</span>
                    </a>
                    <div class=\"dropdown-menu dropdown-menu-right navbar-dropdown preview-list pb-0\" aria-labelledby=\"notificationDropdown\">
                        <a class=\"dropdown-item py-3 border-bottom\">
                            <p class=\"mb-0 font-weight-medium float-left\">You have 4 new notifications </p>
                            <span class=\"badge badge-pill badge-primary float-right\">View all</span>
                        </a>
                        <a class=\"dropdown-item preview-item py-3\">
                            <div class=\"preview-thumbnail\">
                                <i class=\"mdi mdi-alert m-auto text-primary\"></i>
                            </div>
                            <div class=\"preview-item-content\">
                                <h6 class=\"preview-subject font-weight-normal text-dark mb-1\">Application Error</h6>
                                <p class=\"font-weight-light small-text mb-0\"> Just now </p>
                            </div>
                        </a>
                        <a class=\"dropdown-item preview-item py-3\">
                            <div class=\"preview-thumbnail\">
                                <i class=\"mdi mdi-settings m-auto text-primary\"></i>
                            </div>
                            <div class=\"preview-item-content\">
                                <h6 class=\"preview-subject font-weight-normal text-dark mb-1\">Settings</h6>
                                <p class=\"font-weight-light small-text mb-0\"> Private message </p>
                            </div>
                        </a>
                        <a class=\"dropdown-item preview-item py-3\">
                            <div class=\"preview-thumbnail\">
                                <i class=\"mdi mdi-airballoon m-auto text-primary\"></i>
                            </div>
                            <div class=\"preview-item-content\">
                                <h6 class=\"preview-subject font-weight-normal text-dark mb-1\">New user registration</h6>
                                <p class=\"font-weight-light small-text mb-0\"> 2 days ago </p>
                            </div>
                        </a>
                    </div>
                </li>
                <li class=\"nav-item dropdown d-none d-xl-inline-block user-dropdown\">
                    <a class=\"nav-link dropdown-toggle\" id=\"UserDropdown\" href=\"#\" data-toggle=\"dropdown\" aria-expanded=\"false\">
                        <img class=\"img-xs rounded-circle\" src=\"{{ asset('images/faces/face8.jpg') }}\" alt=\"Profile image\"> </a>
                    <div class=\"dropdown-menu dropdown-menu-right navbar-dropdown\" aria-labelledby=\"UserDropdown\">
                        <div class=\"dropdown-header text-center\">
                            <img class=\"img-md rounded-circle\" src=\"{{ asset('images/faces/face8.jpg') }}\" alt=\"Profile image\">
                            <p class=\"mb-1 mt-3 font-weight-semibold\">Allen Moreno</p>
                            <p class=\"font-weight-light text-muted mb-0\">allenmoreno@gmail.com</p>
                        </div>
                        <a class=\"dropdown-item\">Mon Profile <span class=\"badge badge-pill badge-danger\">1</span><i class=\"dropdown-item-icon ti-dashboard\"></i></a>
                        <a class=\"dropdown-item\">Messages<i class=\"dropdown-item-icon ti-comment-alt\"></i></a>
                        <a class=\"dropdown-item\">Sign Out<i class=\"dropdown-item-icon ti-power-off\"></i></a>
                    </div>
                </li>
            </ul>
            <button class=\"navbar-toggler navbar-toggler-right d-lg-none align-self-center\" type=\"button\" data-toggle=\"offcanvas\">
                <span class=\"mdi mdi-menu\"></span>
            </button>
        </div>
    </nav>
    <!-- partial -->
    <div class=\"container-fluid page-body-wrapper\">
        <!-- partial:partials/_sidebar.html -->
        <nav class=\"sidebar sidebar-offcanvas\" id=\"sidebar\">
            <ul class=\"nav\">
                <li class=\"nav-item nav-profile\">
                    <a href=\"#\" class=\"nav-link\">
                        <div class=\"profile-image\">
                            <img class=\"img-xs rounded-circle\" src=\"{{ asset('images/faces/face8.jpg') }}\" alt=\"profile image\">
                            <div class=\"dot-indicator bg-success\"></div>
                        </div>
                    </a>
                </li>
                <li class=\"nav-item nav-category\">Acceuil</li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" href=\"{{ path('back') }}\">
                        <i class=\"menu-icon typcn typcn-document-text\"></i>
                        <span class=\"menu-title\">Acceuil</span>
                    </a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" data-toggle=\"collapse\" href=\"#ui-basic\" aria-expanded=\"false\" aria-controls=\"ui-basic\">
                        <i class=\"menu-icon typcn typcn-coffee\"></i>
                        <span class=\"menu-title\">Espace Entreprise</span>
                        <i class=\"menu-arrow\"></i>
                    </a>
                    <div class=\"collapse\" id=\"ui-basic\">
                        <ul class=\"nav flex-column sub-menu\">
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"pages/ui-features/buttons.html\">Comptes</a>
                            </li>
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"pages/ui-features/dropdowns.html\">Offres</a>
                            </li>
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"pages/ui-features/typography.html\">Réclamations</a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" data-toggle=\"collapse\" href=\"#auth\" aria-expanded=\"false\" aria-controls=\"auth\">
                        <i class=\"menu-icon typcn typcn-document-add\"></i>
                        <span class=\"menu-title\">Espace Candidat</span>
                        <i class=\"menu-arrow\"></i>
                    </a>
                    <div class=\"collapse\" id=\"auth\">
                        <ul class=\"nav flex-column sub-menu\">
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"pages/samples/blank-page.html\"> Comptes </a>
                            </li>
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"{{path('list_demande_back')}}\"> Demandes </a>
                            </li>
                            <li class=\"nav-item\">
                                <a class=\"nav-link\" href=\"pages/samples/register.html\"> Candidatures </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link\" href=\"pages/charts/chartjs.html\">
                        <i class=\"menu-icon typcn typcn-th-large-outline\"></i>
                        <span class=\"menu-title\">Charts</span>
                    </a>
                </li>
            </ul>
        </nav>

{% block body %}

{% endblock %}




</html>
", "baseBack.html.twig", "C:\\Users\\User\\Documents\\pidev\\ProjPiDev\\templates\\baseBack.html.twig");
    }
}
